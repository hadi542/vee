
import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { InterviewRoom } from './components/InterviewRoom';
import { InvestorReport } from './components/InvestorReport';
import { StartupInfo, ChatMessage, EvaluationReport, AppState } from './types';
import { geminiService } from './services/geminiService';
import { Trophy, Rocket, Star, Loader2 } from 'lucide-react';
import { GlassCard } from './components/GlassCard';

const App: React.FC = () => {
  const [state, setState] = useState<AppState>({
    currentView: 'dashboard',
    selectedStartup: null,
    interviewHistory: [],
    finalReport: null
  });

  const [allStartups, setAllStartups] = useState<StartupInfo[]>([]);
  const [isGeneratingReport, setIsGeneratingReport] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('vv_startups');
    if (saved) setAllStartups(JSON.parse(saved));
  }, []);

  const handleStartInterview = (info: StartupInfo) => {
    setAllStartups(prev => {
      const filtered = prev.filter(s => s.id !== info.id);
      const updated = [info, ...filtered];
      localStorage.setItem('vv_startups', JSON.stringify(updated));
      return updated;
    });
    setState({
      ...state,
      currentView: 'interview',
      selectedStartup: info,
      interviewHistory: [],
      finalReport: null
    });
  };

  const handleInterviewComplete = async (history: ChatMessage[]) => {
    if (!state.selectedStartup) return;
    
    setIsGeneratingReport(true);
    try {
      const report = await geminiService.generateReport(state.selectedStartup, history);
      setState({
        ...state,
        currentView: 'report',
        interviewHistory: history,
        finalReport: report
      });
    } catch (error) {
      console.error("Failed to generate report", error);
      alert("Failed to generate report. Please try again.");
    } finally {
      setIsGeneratingReport(false);
    }
  };

  const renderLeaderboard = () => (
    <div className="p-12 max-w-4xl mx-auto">
      <div className="flex items-center gap-6 mb-12">
        <div className="bg-yellow-500/20 p-4 rounded-3xl">
          <Trophy className="w-10 h-10 text-yellow-500" />
        </div>
        <div>
          <h2 className="text-4xl font-black tracking-tight">Elite Ventures</h2>
          <p className="text-slate-400">The highest-scoring startups evaluated by our AI VC.</p>
        </div>
      </div>
      
      <div className="space-y-6">
        {[1, 2, 3].map(i => (
          <GlassCard key={i} className="flex items-center justify-between p-8">
            <div className="flex items-center gap-8">
              <span className="text-3xl font-black text-slate-700">#0{i}</span>
              <div>
                <h4 className="font-black text-xl">Sample Startup {i}</h4>
                <p className="text-sm text-slate-500 font-bold uppercase tracking-widest">AI & Data Infrastructure</p>
              </div>
            </div>
            <div className="flex items-center gap-3 bg-blue-600/10 px-6 py-3 rounded-2xl border border-blue-500/20">
              <Star className="w-5 h-5 text-blue-400 fill-blue-400" />
              <span className="font-black text-xl text-blue-400">9.{10-i}</span>
            </div>
          </GlassCard>
        ))}
        <div className="text-center py-20 text-slate-600 font-bold italic">
          Leaderboard is currently in demo mode.
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#020617] text-slate-200 flex">
      <Sidebar 
        currentView={state.currentView} 
        onViewChange={(view) => setState({ ...state, currentView: view })} 
      />
      
      <main className="flex-1 ml-64 min-h-screen relative">
        {isGeneratingReport && (
          <div className="fixed inset-0 z-[100] bg-slate-950/90 backdrop-blur-2xl flex flex-col items-center justify-center">
            <div className="relative mb-12">
              <div className="w-32 h-32 border-4 border-blue-600/10 border-t-blue-600 rounded-full animate-spin" />
              <Rocket className="w-12 h-12 text-blue-400 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 animate-pulse" />
            </div>
            <h3 className="text-3xl font-black mb-4">Synthesizing Investment Memo</h3>
            <div className="flex flex-col items-center gap-2 text-slate-400 font-medium">
              <p className="animate-pulse">Analyzing market attractiveness...</p>
              <p className="animate-pulse [animation-delay:0.2s]">Evaluating founder capability...</p>
              <p className="animate-pulse [animation-delay:0.4s]">Calculating execution risk...</p>
            </div>
          </div>
        )}

        {state.currentView === 'dashboard' && (
          <Dashboard 
            startups={allStartups} 
            onStartInterview={handleStartInterview} 
          />
        )}

        {state.currentView === 'interview' && state.selectedStartup && (
          <InterviewRoom 
            startup={state.selectedStartup} 
            onComplete={handleInterviewComplete} 
          />
        )}

        {state.currentView === 'report' && state.finalReport && state.selectedStartup && (
          <InvestorReport 
            report={state.finalReport} 
            startup={state.selectedStartup}
            onBack={() => setState({ ...state, currentView: 'dashboard' })}
          />
        )}

        {state.currentView === 'leaderboard' && renderLeaderboard()}
      </main>
    </div>
  );
};

export default App;
