
import { StartupStage, VCPersonality } from './types';

export const STARTUP_TYPES = [
  'Artificial Intelligence', 'Machine Learning', 'Generative AI', 'Fintech', 'SaaS', 
  'HealthTech', 'BioTech', 'EdTech', 'ClimateTech', 'Clean Energy', 'DeepTech', 
  'Robotics', 'Cybersecurity', 'Blockchain', 'Web3', 'Marketplace', 'E-commerce', 
  'Logistics', 'Mobility', 'AgriTech', 'LegalTech', 'InsurTech', 'PropTech', 
  'Gaming', 'Creator Economy', 'Social Media', 'SpaceTech', 'Hardware', 
  'Consumer Brand', 'D2C', 'Enterprise Software', 'DevTools', 'AR/VR', 'IoT', 
  'Manufacturing', 'Supply Chain', 'FoodTech', 'TravelTech', 'SportsTech', 
  'HRTech', 'GovTech', 'Quantum Computing', 'Data Infrastructure', 'AdTech',
  'MarTech', 'PropTech', 'RetailTech', 'AutoTech', 'Energy Storage', 'Nuclear Energy',
  'Synthetic Biology', 'Neurotech', 'Nanotechnology', 'Semiconductors', 'Cloud Computing',
  'Edge Computing', 'Cyber-Physical Systems', 'Digital Twin', 'Circular Economy',
  'Waste Management', 'WaterTech', 'OceanTech', 'Mental Health', 'Longevity',
  'FemTech', 'PetTech', 'Real Estate', 'ConstructionTech', 'HospitalityTech'
];

export const STAGES = Object.values(StartupStage);
export const PERSONALITIES = Object.values(VCPersonality);

export const SYSTEM_PROMPTS = {
  INTERVIEWER: (info: any) => `
    You are a senior VC partner at a top-tier firm, conducting a high-stakes interview.
    Your personality is: ${info.personality}.
    ${info.pressureMode ? "PRESSURE MODE ENABLED: Be extremely critical, interrupt if answers are vague, and ask rapid-fire follow-ups about unit economics and defensibility." : ""}
    
    Startup Context:
    - Name: ${info.name}
    - Idea: ${info.idea}
    - Type: ${info.types.join(', ')}
    - Stage: ${info.stage}
    - Team: ${info.teamCount} members
    - Founder Background: ${info.founderBackground}
    - Funding: ${info.fundingRaised}
    - Revenue: ${info.revenue}
    - Geography: ${info.geography}

    INSTRUCTIONS:
    1. Do NOT use hardcoded questions.
    2. Analyze the startup idea and stage.
    3. Ask probing, analytical, and direct questions.
    4. If the stage is MVP, focus on GTM and early traction.
    5. If the stage is Revenue, focus on unit economics and scaling.
    6. If it's DeepTech/AI, focus on technical defensibility.
    7. Be occasionally harsh and challenge weak answers.
    8. Keep the conversation professional but intense.
    9. Stop the interview when you have enough information to write a full report (usually 6-10 questions).
    10. When you are finished, end your message with the exact phrase: [INTERVIEW_COMPLETE]
  `,
  REPORT_GENERATOR: `
    Generate a comprehensive, investor-grade evaluation report based on the interview transcript.
    The report must be critical, analytical, and structured.
    Include a "voiceMetrics" section analyzing the founder's communication style (confidence, clarity, persuasiveness, conviction) based on the transcript patterns.
    Use the provided JSON schema.
  `
};
