
import { GoogleGenAI, Type } from '@google/genai';
import { StartupInfo, ChatMessage, EvaluationReport } from '../types';
import { SYSTEM_PROMPTS } from '../constants';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string, vertexai: true });

export const geminiService = {
  async generateQuestion(info: StartupInfo, history: ChatMessage[]): Promise<string> {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [
        {
          role: 'user',
          parts: [
            { text: SYSTEM_PROMPTS.INTERVIEWER(info) },
            ...history.map(msg => ({ text: `${msg.role === 'user' ? 'Founder' : 'VC'}: ${msg.text}` })),
            { text: "VC: " }
          ]
        }
      ],
      config: {
        temperature: 0.8,
      }
    });
    return response.text;
  },

  async generateReport(info: StartupInfo, history: ChatMessage[]): Promise<EvaluationReport> {
    const transcript = history.map(m => `${m.role.toUpperCase()}: ${m.text}`).join('\n\n');
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [
        {
          role: 'user',
          parts: [{ text: `Based on this interview transcript for the startup "${info.name}", generate a detailed investor report.\n\nTranscript:\n${transcript}` }]
        }
      ],
      config: {
        systemInstruction: SYSTEM_PROMPTS.REPORT_GENERATOR,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            fundraisingPotential: {
              type: Type.OBJECT,
              properties: {
                range: { type: Type.STRING },
                probability: { type: Type.NUMBER }
              },
              required: ['range', 'probability']
            },
            harshFeedback: { type: Type.STRING },
            coreStrengths: { type: Type.ARRAY, items: { type: Type.STRING } },
            criticalWeaknesses: { type: Type.ARRAY, items: { type: Type.STRING } },
            suggestedImprovements: { type: Type.ARRAY, items: { type: Type.STRING } },
            scores: {
              type: Type.OBJECT,
              properties: {
                marketAttractiveness: { type: Type.NUMBER },
                founderCapability: { type: Type.NUMBER },
                executionRisk: { type: Type.NUMBER },
                technicalDefensibility: { type: Type.NUMBER }
              },
              required: ['marketAttractiveness', 'founderCapability', 'executionRisk', 'technicalDefensibility']
            },
            voiceMetrics: {
              type: Type.OBJECT,
              properties: {
                confidence: { type: Type.NUMBER },
                clarity: { type: Type.NUMBER },
                persuasiveness: { type: Type.NUMBER },
                conviction: { type: Type.NUMBER }
              },
              required: ['confidence', 'clarity', 'persuasiveness', 'conviction']
            },
            competitiveLandscape: { type: Type.STRING },
            similarStartups: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  description: { type: Type.STRING }
                },
                required: ['name', 'description']
              }
            },
            pitchDeckOutline: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: [
            'fundraisingPotential', 'harshFeedback', 'coreStrengths', 
            'criticalWeaknesses', 'suggestedImprovements', 'scores', 
            'competitiveLandscape', 'similarStartups', 'pitchDeckOutline',
            'voiceMetrics'
          ]
        }
      }
    });

    return JSON.parse(response.text);
  }
};
