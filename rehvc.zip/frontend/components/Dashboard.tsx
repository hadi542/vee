
import React, { useState } from 'react';
import { Plus, ArrowRight, Rocket, Users, Globe, Briefcase, Zap, Search, X } from 'lucide-react';
import { GlassCard } from './GlassCard';
import { StartupInfo, StartupStage, VCPersonality } from '../types';
import { STARTUP_TYPES, STAGES, PERSONALITIES } from '../constants';

interface DashboardProps {
  startups: StartupInfo[];
  onStartInterview: (info: StartupInfo) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ startups, onStartInterview }) => {
  const [showForm, setShowForm] = useState(false);
  const [typeSearch, setTypeSearch] = useState('');
  const [formData, setFormData] = useState<Partial<StartupInfo>>({
    name: '',
    idea: '',
    types: [],
    teamCount: 1,
    founderBackground: '',
    fundingRaised: '',
    revenue: '',
    geography: '',
    stage: StartupStage.IDEA,
    personality: VCPersonality.YC,
    pressureMode: false
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newStartup: StartupInfo = {
      ...formData as StartupInfo,
      id: Math.random().toString(36).substr(2, 9),
      timestamp: Date.now()
    };
    onStartInterview(newStartup);
  };

  const toggleType = (type: string) => {
    setFormData(prev => ({
      ...prev,
      types: prev.types?.includes(type)
        ? prev.types.filter(t => t !== type)
        : [...(prev.types || []), type]
    }));
  };

  const filteredTypes = STARTUP_TYPES.filter(t => 
    t.toLowerCase().includes(typeSearch.toLowerCase())
  );

  return (
    <div className="p-8 max-w-6xl mx-auto">
      <div className="flex justify-between items-center mb-12">
        <div>
          <h2 className="text-4xl font-black mb-2 tracking-tight">REHVC Dashboard</h2>
          <p className="text-slate-400">The elite gateway for founders seeking critical AI-driven venture analysis.</p>
        </div>
        {!showForm && (
          <button
            onClick={() => setShowForm(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-2xl flex items-center gap-2 transition-all shadow-lg shadow-blue-600/20 font-bold"
          >
            <Plus className="w-5 h-5" />
            Submit New Startup
          </button>
        )}
      </div>

      {showForm ? (
        <GlassCard className="mb-12 border-blue-500/20">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-2xl font-bold">Startup Submission</h3>
            <button onClick={() => setShowForm(false)} className="text-slate-500 hover:text-white">
              <X className="w-6 h-6" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Startup Name</label>
                <input
                  required
                  type="text"
                  className="w-full bg-slate-900/50 border border-white/10 rounded-2xl px-6 py-4 focus:outline-none focus:border-blue-500 transition-all text-white placeholder:text-slate-600"
                  placeholder="Enter your startup's name"
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Target Geography</label>
                <input
                  required
                  type="text"
                  className="w-full bg-slate-900/50 border border-white/10 rounded-2xl px-6 py-4 focus:outline-none focus:border-blue-500 transition-all text-white placeholder:text-slate-600"
                  placeholder="e.g. Global, North America, SEA"
                  value={formData.geography}
                  onChange={e => setFormData({ ...formData, geography: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Startup Idea & Value Proposition</label>
              <textarea
                required
                rows={4}
                className="w-full bg-slate-900/50 border border-white/10 rounded-2xl px-6 py-4 focus:outline-none focus:border-blue-500 transition-all text-white placeholder:text-slate-600"
                placeholder="What problem are you solving? How is your solution unique?"
                value={formData.idea}
                onChange={e => setFormData({ ...formData, idea: e.target.value })}
              />
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Startup Type (Multi-select)</label>
                <div className="relative w-64">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                  <input 
                    type="text"
                    placeholder="Search types..."
                    className="w-full bg-slate-900/50 border border-white/10 rounded-xl pl-10 pr-4 py-2 text-xs focus:outline-none focus:border-blue-500"
                    value={typeSearch}
                    onChange={e => setTypeSearch(e.target.value)}
                  />
                </div>
              </div>
              <div className="flex flex-wrap gap-2 max-h-48 overflow-y-auto p-4 bg-slate-900/50 rounded-2xl border border-white/10">
                {filteredTypes.map(type => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => toggleType(type)}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-all border ${
                      formData.types?.includes(type)
                        ? 'bg-blue-600 border-blue-500 text-white'
                        : 'bg-white/5 border-white/5 text-slate-400 hover:bg-white/10'
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Team Members Count</label>
                <input
                  type="number"
                  min="1"
                  className="w-full bg-slate-900/50 border border-white/10 rounded-2xl px-6 py-4 focus:outline-none focus:border-blue-500 transition-all text-white"
                  value={formData.teamCount}
                  onChange={e => setFormData({ ...formData, teamCount: parseInt(e.target.value) })}
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Current Stage</label>
                <select
                  className="w-full bg-slate-900/50 border border-white/10 rounded-2xl px-6 py-4 focus:outline-none focus:border-blue-500 transition-all text-white appearance-none"
                  value={formData.stage}
                  onChange={e => setFormData({ ...formData, stage: e.target.value as StartupStage })}
                >
                  {STAGES.map(s => <option key={s} value={s} className="bg-slate-900">{s}</option>)}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Interviewer Persona</label>
                <select
                  className="w-full bg-slate-900/50 border border-white/10 rounded-2xl px-6 py-4 focus:outline-none focus:border-blue-500 transition-all text-white appearance-none"
                  value={formData.personality}
                  onChange={e => setFormData({ ...formData, personality: e.target.value as VCPersonality })}
                >
                  {PERSONALITIES.map(p => <option key={p} value={p} className="bg-slate-900">{p}</option>)}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Previous Funding Raised</label>
                <input
                  type="text"
                  className="w-full bg-slate-900/50 border border-white/10 rounded-2xl px-6 py-4 focus:outline-none focus:border-blue-500 transition-all text-white placeholder:text-slate-600"
                  placeholder="e.g. $250k Angel, $1M Seed, or None"
                  value={formData.fundingRaised}
                  onChange={e => setFormData({ ...formData, fundingRaised: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Revenue (if any)</label>
                <input
                  type="text"
                  className="w-full bg-slate-900/50 border border-white/10 rounded-2xl px-6 py-4 focus:outline-none focus:border-blue-500 transition-all text-white placeholder:text-slate-600"
                  placeholder="e.g. $15k MRR, $200k ARR, or Pre-revenue"
                  value={formData.revenue}
                  onChange={e => setFormData({ ...formData, revenue: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Founders' Background</label>
              <textarea
                rows={3}
                className="w-full bg-slate-900/50 border border-white/10 rounded-2xl px-6 py-4 focus:outline-none focus:border-blue-500 transition-all text-white placeholder:text-slate-600"
                placeholder="Briefly describe the team's expertise and previous exits/experience..."
                value={formData.founderBackground}
                onChange={e => setFormData({ ...formData, founderBackground: e.target.value })}
              />
            </div>

            <div className="flex items-center justify-between p-6 bg-blue-600/10 rounded-2xl border border-blue-500/20">
              <div className="flex items-center gap-4">
                <div className="bg-blue-600 p-3 rounded-xl">
                  <Zap className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="font-bold text-blue-400">Pressure Mode</h4>
                  <p className="text-xs text-slate-400">AI will be significantly more critical, aggressive, and interruptive.</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setFormData({ ...formData, pressureMode: !formData.pressureMode })}
                className={`w-14 h-8 rounded-full transition-all relative ${formData.pressureMode ? 'bg-blue-600' : 'bg-slate-700'}`}
              >
                <div className={`absolute top-1 w-6 h-6 bg-white rounded-full transition-all ${formData.pressureMode ? 'left-7' : 'left-1'}`} />
              </button>
            </div>

            <div className="flex justify-end gap-4 pt-4">
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="px-8 py-4 rounded-2xl text-slate-400 hover:bg-white/5 transition-all font-bold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-blue-600 hover:bg-blue-700 text-white px-10 py-4 rounded-2xl font-bold transition-all flex items-center gap-2 shadow-xl shadow-blue-600/20"
              >
                Initialize AI Interview <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          </form>
        </GlassCard>
      ) : (
        <div className="space-y-6">
          {startups.length === 0 ? (
            <div className="text-center py-32 glass rounded-[2.5rem] border-dashed border-2 border-white/10">
              <Rocket className="w-20 h-20 text-slate-700 mx-auto mb-6" />
              <h3 className="text-2xl font-bold text-slate-400">No ventures submitted</h3>
              <p className="text-slate-500 mt-2">Your journey to funding starts with a single submission.</p>
            </div>
          ) : (
            <div className="overflow-hidden glass rounded-3xl border border-white/10">
              <table className="w-full text-left">
                <thead className="bg-white/5 border-b border-white/10">
                  <tr>
                    <th className="px-8 py-5 text-xs font-bold text-slate-500 uppercase tracking-widest">Startup</th>
                    <th className="px-8 py-5 text-xs font-bold text-slate-500 uppercase tracking-widest">Stage</th>
                    <th className="px-8 py-5 text-xs font-bold text-slate-500 uppercase tracking-widest">Team</th>
                    <th className="px-8 py-5 text-xs font-bold text-slate-500 uppercase tracking-widest">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {startups.map(s => (
                    <tr key={s.id} className="hover:bg-white/5 transition-all group">
                      <td className="px-8 py-6">
                        <div className="font-bold text-lg">{s.name}</div>
                        <div className="text-xs text-slate-500 mt-1">{s.types.slice(0, 2).join(' • ')}</div>
                      </td>
                      <td className="px-8 py-6">
                        <span className="text-xs bg-blue-500/10 text-blue-400 px-3 py-1.5 rounded-full font-bold border border-blue-500/20">{s.stage}</span>
                      </td>
                      <td className="px-8 py-6 text-slate-400 font-medium">{s.teamCount} members</td>
                      <td className="px-8 py-6">
                        <button 
                          onClick={() => onStartInterview(s)}
                          className="bg-white/5 hover:bg-blue-600 text-slate-300 hover:text-white px-4 py-2 rounded-xl text-sm font-bold transition-all flex items-center gap-2"
                        >
                          Interview <ArrowRight className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
