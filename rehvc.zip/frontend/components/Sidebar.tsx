
import React from 'react';
import { LayoutDashboard, MessageSquare, FileText, Trophy, Rocket, Settings } from 'lucide-react';

interface SidebarProps {
  currentView: string;
  onViewChange: (view: any) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, onViewChange }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'interview', label: 'Interview', icon: MessageSquare },
    { id: 'report', label: 'Reports', icon: FileText },
    { id: 'leaderboard', label: 'Leaderboard', icon: Trophy },
  ];

  return (
    <div className="w-64 h-screen glass border-r border-white/10 flex flex-col p-6 fixed left-0 top-0 z-50">
      <div className="flex items-center gap-3 py-8 mb-12">
        <div className="bg-blue-600 p-2.5 rounded-xl shadow-lg shadow-blue-600/30">
          <Rocket className="w-6 h-6 text-white" />
        </div>
        <h1 className="text-2xl font-black tracking-tighter text-white">REHVC</h1>
      </div>

      <nav className="flex-1 space-y-3">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onViewChange(item.id)}
            className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl transition-all duration-300 ${
              currentView === item.id
                ? 'bg-blue-600 text-white shadow-xl shadow-blue-600/20'
                : 'text-slate-500 hover:bg-white/5 hover:text-slate-200'
            }`}
          >
            <item.icon className={`w-5 h-5 ${currentView === item.id ? 'text-white' : 'text-slate-500'}`} />
            <span className="font-bold text-sm">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="mt-auto space-y-4">
        <div className="p-5 glass rounded-2xl border-blue-500/10">
          <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest mb-3">System Status</p>
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-300">AI Engine</span>
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />
              <span className="text-[10px] text-green-500 font-black uppercase">Active</span>
            </div>
          </div>
        </div>
        <button className="w-full flex items-center gap-4 px-5 py-4 rounded-2xl text-slate-500 hover:bg-white/5 hover:text-slate-200 transition-all">
          <Settings className="w-5 h-5" />
          <span className="font-bold text-sm">Settings</span>
        </button>
      </div>
    </div>
  );
};
