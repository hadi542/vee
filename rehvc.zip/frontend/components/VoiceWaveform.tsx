
import React from 'react';
import { motion } from 'framer-motion';

interface VoiceWaveformProps {
  isActive: boolean;
  color?: string;
  count?: number;
}

export const VoiceWaveform: React.FC<VoiceWaveformProps> = ({ isActive, color = "bg-blue-500", count = 12 }) => {
  const bars = Array.from({ length: count });

  return (
    <div className="flex items-center justify-center gap-1 h-12">
      {bars.map((_, i) => (
        <motion.div
          key={i}
          className={`w-1.5 rounded-full ${color}`}
          animate={isActive ? {
            height: [10, Math.random() * 40 + 10, 10],
          } : {
            height: 10
          }}
          transition={isActive ? {
            duration: 0.5,
            repeat: Infinity,
            delay: i * 0.05,
            ease: "easeInOut"
          } : {}}
        />
      ))}
    </div>
  );
};
