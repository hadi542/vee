
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Send, Loader2, User, Bot, CheckCircle2, AlertCircle, Mic, MicOff, Volume2, VolumeX, MessageSquare, Play, Pause } from 'lucide-react';
import { StartupInfo, ChatMessage } from '../types';
import { geminiService } from '../services/geminiService';
import { GlassCard } from './GlassCard';
import { VoiceWaveform } from './VoiceWaveform';

interface InterviewRoomProps {
  startup: StartupInfo;
  onComplete: (history: ChatMessage[]) => void;
}

export const InterviewRoom: React.FC<InterviewRoomProps> = ({ startup, onComplete }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const [isVoiceMode, setIsVoiceMode] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [hasStarted, setHasStarted] = useState(false);
  
  const scrollRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  const silenceTimerRef = useRef<any>(null);

  // Initialize Speech Recognition
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        processMessage(transcript);
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error('Speech recognition error', event.error);
        setIsListening(false);
      };
    }
  }, []);

  const startListening = useCallback(() => {
    if (recognitionRef.current && !isListening && !isSpeaking && !isComplete) {
      try {
        recognitionRef.current.start();
        setIsListening(true);
        
        // Silence detection
        if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
        silenceTimerRef.current = setTimeout(() => {
          if (isListening) {
            recognitionRef.current.stop();
            // Optionally ask "Are you still there?"
          }
        }, 8000);
      } catch (e) {
        console.error("Failed to start recognition", e);
      }
    }
  }, [isListening, isSpeaking, isComplete]);

  const speakText = useCallback((text: string) => {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text.replace('[INTERVIEW_COMPLETE]', ''));
    
    const voices = window.speechSynthesis.getVoices();
    const preferredVoice = voices.find(v => v.name.includes('Google US English') || v.name.includes('Male')) || voices[0];
    if (preferredVoice) utterance.voice = preferredVoice;
    
    utterance.rate = 1.0;
    utterance.pitch = 1;
    
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => {
      setIsSpeaking(false);
      if (isVoiceMode && !isComplete) {
        setTimeout(startListening, 500);
      }
    };

    window.speechSynthesis.speak(utterance);
  }, [isVoiceMode, isComplete, startListening]);

  const processMessage = async (text: string) => {
    if (!text.trim() || isLoading || isComplete) return;

    const userMsg = text.trim();
    const newHistory: ChatMessage[] = [...messages, { role: 'user', text: userMsg }];
    
    setInput('');
    setMessages(newHistory);
    setIsLoading(true);
    setIsListening(false);

    try {
      const response = await geminiService.generateQuestion(startup, newHistory);
      const isFinished = response.includes('[INTERVIEW_COMPLETE]');
      const cleanResponse = response.replace('[INTERVIEW_COMPLETE]', '').trim();
      
      const updatedHistory: ChatMessage[] = [...newHistory, { role: 'model', text: cleanResponse }];
      setMessages(updatedHistory);
      
      if (isFinished) {
        setIsComplete(true);
      }

      if (isVoiceMode) {
        speakText(cleanResponse);
      }
    } catch (error) {
      console.error(error);
      setMessages([...newHistory, { role: 'model', text: "I'm having trouble processing that. Could you repeat?" }]);
    } finally {
      setIsLoading(false);
    }
  };

  const startInterview = async () => {
    setHasStarted(true);
    setIsLoading(true);
    try {
      const firstMsg = await geminiService.generateQuestion(startup, []);
      setMessages([{ role: 'model', text: firstMsg }]);
      if (isVoiceMode) {
        speakText(firstMsg);
      }
    } catch (error) {
      console.error(error);
      setMessages([{ role: 'model', text: "Error starting interview. Please refresh." }]);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const toggleVoiceMode = () => {
    const newMode = !isVoiceMode;
    setIsVoiceMode(newMode);
    if (!newMode) {
      window.speechSynthesis.cancel();
      if (recognitionRef.current) recognitionRef.current.stop();
      setIsListening(false);
      setIsSpeaking(false);
    } else if (hasStarted) {
      const lastMsg = messages[messages.length - 1];
      if (lastMsg && lastMsg.role === 'model') {
        speakText(lastMsg.text);
      }
    }
  };

  if (!hasStarted) {
    return (
      <div className="flex flex-col items-center justify-center h-[calc(100vh-4rem)] p-8">
        <GlassCard className="max-w-xl w-full text-center p-12 space-y-8">
          <div className="w-24 h-24 bg-blue-600/20 rounded-full flex items-center justify-center mx-auto">
            <Bot className="w-12 h-12 text-blue-500" />
          </div>
          <div className="space-y-4">
            <h2 className="text-3xl font-bold">Ready for your interview?</h2>
            <p className="text-slate-400">
              You are about to enter a high-stakes session with a {startup.personality} partner. 
              {startup.pressureMode && " Pressure Mode is active—expect tough questions."}
            </p>
          </div>
          <div className="flex flex-col gap-4">
            <button
              onClick={() => { setIsVoiceMode(true); startInterview(); }}
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-2xl font-bold text-lg transition-all flex items-center justify-center gap-3 voice-glow"
            >
              <Mic className="w-6 h-6" /> Start Voice Interview
            </button>
            <button
              onClick={() => { setIsVoiceMode(false); startInterview(); }}
              className="glass hover:bg-white/10 text-slate-300 px-8 py-4 rounded-2xl font-bold transition-all flex items-center justify-center gap-3"
            >
              <MessageSquare className="w-6 h-6" /> Start Text Interview
            </button>
          </div>
        </GlassCard>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto h-[calc(100vh-4rem)] flex flex-col p-4">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center shadow-lg shadow-blue-600/20">
            <Bot className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold">{startup.personality}</h2>
            <p className="text-sm text-slate-400">{startup.name} • {startup.stage}</p>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <button
            onClick={toggleVoiceMode}
            className={`flex items-center gap-2 px-4 py-2 rounded-full transition-all ${
              isVoiceMode 
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/40' 
                : 'glass text-slate-400 hover:text-white'
            }`}
          >
            {isVoiceMode ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            <span className="text-xs font-bold uppercase tracking-wider">
              {isVoiceMode ? 'Voice Mode' : 'Text Mode'}
            </span>
          </button>
        </div>
      </div>

      <GlassCard className="flex-1 flex flex-col overflow-hidden mb-4 relative">
        {isVoiceMode && (
          <div className="absolute inset-x-0 top-0 z-10 p-4 flex justify-center pointer-events-none">
            <div className="glass px-6 py-3 rounded-2xl flex items-center gap-8 shadow-2xl border-blue-500/30">
              <div className="flex flex-col items-center">
                <span className="text-[10px] uppercase font-bold text-slate-500 mb-1">VC Speaking</span>
                <VoiceWaveform isActive={isSpeaking} color="bg-blue-400" />
              </div>
              <div className="w-px h-8 bg-white/10" />
              <div className="flex flex-col items-center">
                <span className="text-[10px] uppercase font-bold text-slate-500 mb-1">Founder Listening</span>
                <VoiceWaveform isActive={isListening} color="bg-green-400" />
              </div>
            </div>
          </div>
        )}

        <div ref={scrollRef} className={`flex-1 overflow-y-auto p-6 space-y-6 ${isVoiceMode ? 'pt-24' : ''}`}>
          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[85%] flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                <div className={`w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center ${
                  msg.role === 'user' ? 'bg-slate-700' : 'bg-blue-900/50'
                }`}>
                  {msg.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4 text-blue-400" />}
                </div>
                <div className={`rounded-2xl px-5 py-3 text-sm leading-relaxed ${
                  msg.role === 'user' 
                    ? 'bg-blue-600 text-white rounded-tr-none' 
                    : 'bg-slate-800/50 text-slate-200 rounded-tl-none border border-white/10'
                }`}>
                  {msg.text}
                </div>
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-full bg-blue-900/50 flex items-center justify-center">
                  <Loader2 className="w-4 h-4 text-blue-400 animate-spin" />
                </div>
                <div className="bg-slate-800/50 rounded-2xl px-5 py-3 rounded-tl-none border border-white/10">
                  <div className="flex gap-1">
                    <div className="w-1.5 h-1.5 bg-slate-500 rounded-full animate-bounce" />
                    <div className="w-1.5 h-1.5 bg-slate-500 rounded-full animate-bounce [animation-delay:0.2s]" />
                    <div className="w-1.5 h-1.5 bg-slate-500 rounded-full animate-bounce [animation-delay:0.4s]" />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {isComplete ? (
          <div className="p-8 bg-green-500/10 border-t border-green-500/20 text-center">
            <div className="flex items-center justify-center gap-2 text-green-400 mb-4">
              <CheckCircle2 className="w-6 h-6" />
              <span className="font-bold text-xl">Interview Concluded</span>
            </div>
            <p className="text-slate-400 mb-6">The VC has gathered enough information to generate your investment memo.</p>
            <button
              onClick={() => onComplete(messages)}
              className="bg-green-600 hover:bg-green-700 text-white px-10 py-4 rounded-2xl font-bold text-lg transition-all shadow-lg shadow-green-600/20"
            >
              Generate Investor Report
            </button>
          </div>
        ) : (
          <div className="p-6 border-t border-white/10">
            {isVoiceMode ? (
              <div className="flex flex-col items-center gap-4 py-4">
                <button
                  onClick={() => isListening ? recognitionRef.current?.stop() : startListening()}
                  disabled={isSpeaking || isLoading}
                  className={`w-20 h-20 rounded-full flex items-center justify-center transition-all ${
                    isListening 
                      ? 'bg-red-500 animate-pulse shadow-lg shadow-red-500/40' 
                      : 'bg-blue-600 hover:bg-blue-700 shadow-lg shadow-blue-600/40'
                  } disabled:opacity-50`}
                >
                  {isListening ? <MicOff className="w-10 h-10 text-white" /> : <Mic className="w-10 h-10 text-white" />}
                </button>
                <p className="text-sm font-bold tracking-wide text-slate-400 uppercase">
                  {isSpeaking ? 'VC is speaking...' : isListening ? 'Listening to you...' : 'Click to speak your answer'}
                </p>
              </div>
            ) : (
              <form onSubmit={(e) => { e.preventDefault(); processMessage(input); }} className="flex gap-3">
                <input
                  type="text"
                  className="flex-1 bg-white/5 border border-white/10 rounded-2xl px-6 py-4 focus:outline-none focus:border-blue-500 transition-all"
                  placeholder="Type your response..."
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  disabled={isLoading}
                />
                <button
                  type="submit"
                  disabled={isLoading || !input.trim()}
                  className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white px-6 rounded-2xl transition-all"
                >
                  <Send className="w-6 h-6" />
                </button>
              </form>
            )}
          </div>
        )}
      </GlassCard>

      <div className="flex items-center justify-between px-2">
        <div className="flex items-center gap-2 text-xs text-slate-500">
          <AlertCircle className="w-3 h-3" />
          <span>AI is analyzing tone, confidence, and business logic.</span>
        </div>
        <button 
          onClick={toggleVoiceMode}
          className="text-xs text-blue-400 hover:text-blue-300 font-bold flex items-center gap-1"
        >
          {isVoiceMode ? <MessageSquare className="w-3 h-3" /> : <Mic className="w-3 h-3" />}
          Switch to {isVoiceMode ? 'Text' : 'Voice'}
        </button>
      </div>
    </div>
  );
};
