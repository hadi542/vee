
export enum StartupStage {
  IDEA = 'Idea',
  MVP = 'MVP',
  REVENUE = 'Revenue',
  SCALING = 'Scaling'
}

export enum VCPersonality {
  YC = 'Y Combinator Style',
  SEQUOIA = 'Sequoia Style',
  SHARK_TANK = 'Shark Tank Style',
  A16Z = 'Andreessen Horowitz Style'
}

export interface StartupInfo {
  id: string;
  name: string;
  idea: string;
  types: string[];
  teamCount: number;
  founderBackground: string;
  fundingRaised: string;
  revenue: string;
  geography: string;
  stage: StartupStage;
  personality: VCPersonality;
  timestamp: number;
  pressureMode?: boolean;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

export interface EvaluationReport {
  fundraisingPotential: {
    range: string;
    probability: number;
  };
  harshFeedback: string;
  coreStrengths: string[];
  criticalWeaknesses: string[];
  suggestedImprovements: string[];
  scores: {
    marketAttractiveness: number;
    founderCapability: number;
    executionRisk: number;
    technicalDefensibility: number;
  };
  voiceMetrics?: {
    confidence: number;
    clarity: number;
    persuasiveness: number;
    conviction: number;
  };
  competitiveLandscape: string;
  similarStartups: {
    name: string;
    description: string;
  }[];
  pitchDeckOutline: string[];
}

export interface AppState {
  currentView: 'dashboard' | 'interview' | 'report' | 'leaderboard';
  selectedStartup: StartupInfo | null;
  interviewHistory: ChatMessage[];
  finalReport: EvaluationReport | null;
}
